#ifndef _bsccs_RCPP_HELLO_WORLD_H
#define _bsccs_RCPP_HELLO_WORLD_H

#include <Rcpp.h>

/*
 * note : RcppExport is an alias to `extern "C"` defined by Rcpp.
 *
 * It gives C calling convention to the rcpp_hello_world function so that 
 * it can be called from .Call in R. Otherwise, the C++ compiler mangles the 
 * name of the function and .Call can't find it.
 *
 * It is only useful to use RcppExport when the function is intended to be called
 * by .Call. See the thread http://thread.gmane.org/gmane.comp.lang.r.rcpp/649/focus=672
 * on Rcpp-devel for a misuse of RcppExport
 */

namespace bsccs { 
 
    RcppExport SEXP load(SEXP inFileName, SEXP inFileFormat);

    RcppExport SEXP update(SEXP rCcd, SEXP rArguments);

    RcppExport SEXP unload(SEXP rCcd, SEXP rData, SEXP rArguments);

    RcppExport SEXP getLogLikelihood(SEXP rCcd);

    RcppExport SEXP getLogPrior(SEXP rCcd);

    RcppExport SEXP getBeta(SEXP rCcd);

    RcppExport SEXP setBeta(SEXP rCcd, SEXP rBeta);
    
    RcppExport SEXP setHyperprior(SEXP rCcd, SEXP rVariance);
    
    RcppExport SEXP getUpdateCount(SEXP rCcd);
    
    RcppExport SEXP getLikelihoodCount(SEXP rCcd);

}; // end namespace

#endif
