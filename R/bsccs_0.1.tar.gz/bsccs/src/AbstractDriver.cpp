/*
 * AbstractDriver.cpp
 *
 *  Created on: Nov 17, 2010
 *      Author: msuchard
 */

#include "AbstractDriver.h"

AbstractDriver::AbstractDriver() {
	// TODO Auto-generated constructor stub

}

AbstractDriver::~AbstractDriver() {
	// TODO Auto-generated destructor stub
}
