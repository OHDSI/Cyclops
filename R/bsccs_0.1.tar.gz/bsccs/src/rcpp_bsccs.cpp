#include "rcpp_bsccs.h"
#include "ccd.h"

namespace bsccs {

SEXP load(SEXP inFileName, SEXP inFileFormat) {
    using namespace Rcpp;
    
    BEGIN_RCPP
        
    std::string myFileName = as<std::string>(inFileName);
    std::string myFileFormat = as<std::string>(inFileFormat);
//    std::cout << "Load filename: " << myFileName << std::endl;
//    CharacterVector rtnFileName = CharacterVector::create(myFileName);
     
    CCDArguments* arguments = new CCDArguments;
    setDefaultArguments(*arguments);

    // Change options
    arguments->inFileName = myFileName;
    arguments->outFileName = "r_out.txt";
    arguments->fileFormat = myFileFormat;
//    arguments->useGPU = false;
//    arguments->useNormalPrior = true;
//    arguments->hyperPriorSet = false;
//    arguments->doLogisticRegression = false;

//    std::vector<std::string> args;
//    args.push_back("R"); // program name
//    args.push_back("short.txt");
//    args.push_back("out.txt");

//	parseCommandLine(args, arguments); // TODO No idea why this doesn't work in Rcpp
	
    CyclicCoordinateDescent* ccd = NULL;
    InputReader* reader = NULL;    
    double timeInitialize = initializeModel(&reader, &ccd, *arguments);
    
    NumericVector rTime = NumericVector::create(timeInitialize);
    Rcpp::XPtr<CCDArguments> rArguments(arguments);
    Rcpp::XPtr<CyclicCoordinateDescent> rCcd(ccd);
    Rcpp::XPtr<InputReader> rReader(reader);
    NumericVector rJ = NumericVector::create(ccd->getBetaSize());
    
    return List::create(rTime, rCcd, rReader, rArguments,
        Rcpp::wrap(reader->getNumberOfPatients()),
        Rcpp::wrap(reader->getNumberOfRows()),
        Rcpp::wrap(ccd->getBetaSize())               
    ); 
            
    END_RCPP    
}

SEXP getLogLikelihood(SEXP rCcd) {
    using namespace Rcpp;
    XPtr<CyclicCoordinateDescent> ccd(rCcd);
    return wrap(ccd->getLogLikelihood());
}

SEXP getLogPrior(SEXP rCcd) {
    using namespace Rcpp;
    XPtr<CyclicCoordinateDescent> ccd(rCcd);
    return wrap(ccd->getLogPrior());
}

SEXP getBeta(SEXP rCcd) {
    using namespace Rcpp;
    XPtr<CyclicCoordinateDescent> ccd(rCcd);
    
    int J = ccd->getBetaSize();
  	std::vector<double> beta;
  	for (int j = 0; j < J; ++j) {
  	    beta.push_back(ccd->getBeta(j));
  	}
    
    return wrap(beta);
}

SEXP setBeta(SEXP rCcd, SEXP rBeta) {
    using namespace Rcpp;
    XPtr<CyclicCoordinateDescent> ccd(rCcd);
    
    std::vector<double> beta = as<std::vector<double> >(rBeta);
    ccd->setBeta(beta);
    
    return rBeta;
}

SEXP setHyperprior(SEXP rCcd, SEXP rVariance) {
    using namespace Rcpp;
    XPtr<CyclicCoordinateDescent> ccd(rCcd);
    std::vector<double> variance = as<std::vector<double> >(rVariance);
    
    ccd->setHyperprior(variance[0]);
    return rVariance;
}

SEXP getUpdateCount(SEXP rCcd) {
    using namespace Rcpp;
    XPtr<CyclicCoordinateDescent> ccd(rCcd);
    return wrap(ccd->getUpdateCount());
}
    
SEXP getLikelihoodCount(SEXP rCcd) {
    using namespace Rcpp;
    XPtr<CyclicCoordinateDescent> ccd(rCcd);
    return wrap(ccd->getLikelihoodCount());
}    

SEXP update(SEXP rCcd, SEXP rArguments) {
    using namespace Rcpp;
    
    BEGIN_RCPP
    
    Rcpp::XPtr<CyclicCoordinateDescent> ccd(rCcd);
    Rcpp::XPtr<CCDArguments> arguments(rArguments);
    
  
//   double timeUpdate = ccd->getBetaSize();
//	double timeUpdate = arguments->tolerance;
  	double timeUpdate = fitModel(ccd, *arguments);
  	
  	double logLike = ccd->getLogLikelihood();
  	double logPrior = ccd->getLogPrior();
  	
  	int J = ccd->getBetaSize();
  	std::vector<double> beta;
  	for (int j = 0; j < J; ++j) {
  	    beta.push_back(ccd->getBeta(j));
  	}
  	
  	return List::create(
  	    Rcpp::wrap(logLike),
  	    Rcpp::wrap(logPrior),
  	    Rcpp::wrap(beta),
  	    Rcpp::wrap(timeUpdate)
  	);
			
// 	return NumericVector::create(timeUpdate);
	
	END_RCPP
}

SEXP unload() {
// 	if (ccd) {
// 		delete ccd;
// 		ccd = NULL;
// 	}
// 	if (reader) {
// 		delete reader;
// 		reader = NULL;
// 	}
// 	
// 	if (arguments) {
// 	    delete arguments;
// 	    arguments = NULL;
// 	}
}

}; // end namespace
