
bsccs_load <- function(file_name, file_format="sccs") {
    tmp = .Call("load", file_name, file_format, PACKAGE="bsccs")
    return(list(
        ptr_ccd=tmp[[2]], 
        ptr_data=tmp[[3]], 
        ptr_arguments=tmp[[4]],
        N=tmp[[5]],
        K=tmp[[6]],
        J=tmp[[7]],
        time.load=tmp[[1]],
        calls.likelihood=0,
        calls.update=0
    ))
}

bsccs_find_mode <- function(bsccs_obj, infer.hyperprior = FALSE, tol=0.01) {
    if (infer.hyperprior == FALSE) {
        tmp = .Call("update", bsccs_obj$ptr_ccd, bsccs_obj$ptr_arguments, PACKAGE="bsccs")   
        cat("Right place\n")        
        return(list(
            logLike=tmp[[1]],
            logPrior=tmp[[2]],
            beta=tmp[[3]],
            hyperprior=NA,
            time.fit=tmp[[4]]            
        ))
    } else {
        beta.length = bsccs_obj$J
        objective = function(x) {          
            .Call("setHyperprior", bsccs_obj$ptr_ccd, x, PACKAGE="bsccs")            
            tmp = .Call("update", bsccs_obj$ptr_ccd, bsccs_obj$ptr_arguments, PACKAGE="bsccs")
            logLike = tmp[[1]]
            logPrior = tmp[[2]]
            cat(paste("x =",x,"like =",logLike,"prior =",logPrior,"\n"))
            return(-tmp[[1]] - tmp[[2]])
        }
        tmp = optimize(f=objective, interval=c(0,100),tol=tol)
        return(list(
            logLike=bsccs_get_log_likelihood(bsccs_obj),
            logPrior=bsccs_get_log_prior(bsccs_obj),
            beta=bsccs_get_beta(bsccs_obj),
            hyperprior=tmp$minimum,
            time.fit=NA
        ))
    }
}

bsccs_unload <- function(bsccs_obj) {
    .Call("unload", bsccs_obj$ptr_ccd, bsccs_obj$ptr_data, bsccs_obj$ptr_arguments, PACKAGE="bsccs")
    return
}

bsccs_get_log_likelihood <- function(bsccs_obj) {
    .Call("getLogLikelihood", bsccs_obj$ptr_ccd, PACKAGE="bsccs")
}

bsccs_get_log_prior <- function(bsccs_obj) {
    .Call("getLogPrior", bsccs_obj$ptr_ccd, PACKAGE="bsccs")
}

bsccs_get_beta <- function(bsccs_obj) {
    .Call("getBeta", bsccs_obj$ptr_ccd, PACKAGE="bsccs")
}

bsccs_set_hyperprior <- function(bsccs_obj, hyperprior) {
    if (length(hyperprior) != 1) {
        error("Variance is the wrong length")        
    }
    .Call("setHyperprior", bsccs_obj$ptr_ccd, hyperprior, PACKAGE="bsccs")
    return
}

bsccs_set_beta <- function(bsccs_obj, beta) {
    if (length(beta) != bsccs_obj$J) {
        error("Beta is the wrong length")
    }
    .Call("setBeta", bsccs_obj$ptr_ccd, beta, PACKAGE="bsccs")
    return
}

bsccs_get_update_count <- function(bsccs_obj) {
    .Call("getUpdateCount", bsccs_obj$ptr_ccd, PACKAGE="bsccs")
}

bsccs_get_likelihood_count <- function(bsccs_obj) {
    .Call("getLikelihoodCount", bsccs_obj$ptr_ccd, PACKAGE="bsccs")
}

test <- function() {
    obj = bsccs_load("infert.txt","csv")
    tmp = bsccs_get_log_likelihood(obj)
    return(tmp)
}
